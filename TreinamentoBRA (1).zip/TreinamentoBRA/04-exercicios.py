# Databricks notebook source
# MAGIC %md
# MAGIC ### 1. Some todos os números de 1 até 100

# COMMAND ----------

soma=0
for nmr in range(1, 101):
    soma += nmr
print(soma)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. Some todos os números pares de 1 até 100

# COMMAND ----------

soma=0
for nmr in list(range(1, 101)):
    if nmr % 2 == 0:
      soma = nmr + soma
print(soma)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3. Some todos os números ímpares de 1 até 100

# COMMAND ----------

soma=0
for nmr in list(range(1, 101)):
    if nmr % 2 != 0:
      soma = nmr + soma
print(soma)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4. Dada a lista abaixo, some todos os elementos inteiros positivos

# COMMAND ----------

lista = [-2, 2, 'celular', 10, -99, False]
lista

# COMMAND ----------

soma=0
for nmr in lista:
    if isinstance(nmr, int) and nmr > 0:
      soma = nmr + soma
print(soma)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5. Dada a String

# COMMAND ----------

string = 'pYthOn É A mELhoR LiNguaGEM De PRoGRaMaçãO'
string

# COMMAND ----------

# MAGIC %md
# MAGIC Formate-a com as primeiras letras maiúsculas:

# COMMAND ----------

string = string.title()
string

# COMMAND ----------

# MAGIC %md
# MAGIC Com todas as letras minúsculas

# COMMAND ----------

string = string.lower()
string

# COMMAND ----------

# MAGIC %md
# MAGIC Com todas as letras maiúsculas

# COMMAND ----------

string = string.upper()
string