# Databricks notebook source
# MAGIC %md
# MAGIC ### 1. Criar um array com 10 números inteiros aleatórios entre 1 e 50 e calcular a média e o desvio padrão

# COMMAND ----------

import numpy as np

array = np.random.randint(low=1, high=50, size=10)
media = np.mean(array)
desvio_padrao = np.std(array)

print("Array:", array)
print("Média:", media)
print("Desvio padrão:", desvio_padrao)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. Criar um array de 10 números aleatórios e calcular a raiz quadrada de todos os valores menores ou iguais a 0,5

# COMMAND ----------

import numpy as np

arr = np.random.rand(10)
print("Array original:", arr)

arr_filtrado = arr[arr <= 0.5]

arr_raiz = np.sqrt(arr_filtrado)
print("Array com raiz quadrada dos valores filtrados:", arr_raiz)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3. Criar uma matriz 3D de tamanho 3x3x3 com valores aleatórios e exibir o valor máximo de cada linha de cada matriz 2D dentro dessa matriz 3D

# COMMAND ----------

matriz = np.random.rand(3, 3, 3)
print(f"Matriz:\n{matriz}\n")

print("Maiores valores de cada linha:")
for i in range(3):
    print(f"Matriz 2D {i+1}: {np.max(matriz[i], axis=1)}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4. Criar uma matriz de tamanho 5x5 com valores aleatórios e subtrair a média de cada linha dessa matriz

# COMMAND ----------

import numpy as np

matriz = np.random.rand(5, 5) 
print(f"Matriz original: \n{matriz}\n")

matriz_media = matriz - matriz.mean(axis=1, keepdims=True)
print(f"Matriz com média de cada linha subtraída: \n{matriz_media}\n")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5. Criar uma matriz de tamanho 4x4 com valores aleatórios e calcular a média e o desvio padrão das diagonais da matriz

# COMMAND ----------

import numpy as np

matriz = np.random.rand(4, 4)

diagonal_principal = np.diag(matriz)
diagonal_secundaria = np.diag(np.fliplr(matriz))

media_diagonais = np.mean([diagonal_principal, diagonal_secundaria])
desvio_padrao_diagonais = np.std([diagonal_principal, diagonal_secundaria])

print(f"Matriz:\n {matriz} \n")
print(f"Diagonal principal: {diagonal_principal}")
print(f"Diagonal secundária: {diagonal_secundaria}")
print(f"Média das diagonais: {media_diagonais}")
print(f"Desvio padrão das diagonais: {desvio_padrao_diagonais}")