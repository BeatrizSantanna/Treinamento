# Databricks notebook source
# MAGIC %md
# MAGIC ### 11. Crie um programa em Python que receba uma lista de números inteiros como entrada e retorne uma nova lista contendo apenas os números que aparecem um número ímpar de vezes.

# COMMAND ----------

numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 8, 7, 6, 5, 4, 3, 2, 1]
dicionario = {}
for num in numeros:
    if num in dicionario:
        dicionario[num] += 1
    else:
        dicionario[num] = 1
impares = []
for num, frequencia in dicionario.items():
    if frequencia % 2 != 0:
        impares.append(num)
print(impares)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 12. Crie um programa em Python que receba duas listas de números inteiros como entrada e retorne uma nova lista contendo apenas os elementos que aparecem em pelo menos uma das listas, mas não em ambas.

# COMMAND ----------

lista1 = [1, 2, 3, 4, 5, 6, 7]
lista2 = [4, 5, 6, 7, 8, 9, 10]

nova_lista = list(set(lista1) ^ set(lista2))

print(nova_lista)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 13. Crie um programa em Python que receba duas listas de números inteiros como entrada e retorne uma nova lista contendo apenas os elementos que aparecem em ambas as listas, mas sem repetições.

# COMMAND ----------

lista1 = [1, 2, 3, 4, 5]
lista2 = [4, 5, 6, 7, 8]

nova_lista = list(set(lista1) & set(lista2))

print(nova_lista)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 14. Crie um programa em Python que receba uma lista de dicionários como entrada, onde cada dicionário representa um produto com nome e preço, e retorne o nome do produto mais caro.

# COMMAND ----------

produtos = [{"nome": "celular", "preco": 1500},
            {"nome": "notebook", "preco": 3500},
            {"nome": "tablet", "preco": 1200},
            {"nome": "fones de ouvido", "preco": 200},
            {"nome": "smartwatch", "preco": 800}]

produto_mais_caro = max(produtos, key=lambda produto: produto["preco"])
nome_do_produto_mais_caro = produto_mais_caro["nome"]

print(nome_do_produto_mais_caro)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 15. Crie um programa em Python que receba um dicionário como entrada, onde as chaves representam nomes de produtos e os valores representam as quantidades disponíveis em estoque, e retorne o nome do produto com estoque mais baixo.

# COMMAND ----------

estoque = {"celular": 50, "notebook": 20, "tablet": 100, "fones de ouvido": 5, "smartwatch": 15}

produto_com_estoque_mais_baixo = min(estoque, key=lambda produto: estoque[produto])

print(produto_com_estoque_mais_baixo)

# COMMAND ----------

