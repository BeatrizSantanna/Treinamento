# Databricks notebook source
# MAGIC %md
# MAGIC ### 21. Crie um programa em Python que receba uma string como entrada e imprima a string sem as vogais.

# COMMAND ----------

texto = input("Digite uma string: ")
nova_string = ""

for letra in texto:
    if letra.lower() not in "aeiou":
        nova_string += letra

print(nova_string)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 22. Crie um programa em Python que imprima a soma dos n primeiros números primos, onde n é um número fornecido pelo usuário.

# COMMAND ----------

n = int(input("Digite um número inteiro positivo: "))
soma = 0
contador = 0
numero = 2

while contador < n:
    primo = True
    for i in range(2, numero):
        if numero % i == 0:
            primo = False
            break
    if primo:
        soma += numero
        contador += 1
    numero += 1

print("A soma dos", n, "primeiros números primos é:", soma)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 23. Crie um programa em Python que receba uma lista de números e imprima a soma dos números pares e a soma dos números ímpares presentes na lista.

# COMMAND ----------

lista = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

soma_pares = 0
soma_impares = 0

for num in lista:
  if num % 2 == 0:
    soma_pares += num
  else:
    soma_impares += num

print("Soma dos números pares: ", soma_pares)
print("Soma dos números ímpares: ", soma_impares)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 24. Crie um programa em Python que receba uma lista de strings e retorne uma lista com todas as strings que começam e terminam com a mesma letra.

# COMMAND ----------

palavras = ["amor", "futebol", "verdade", "banana", "arara", "casa", "sol"]
palavras_selecionadas = []

for palavra in palavras:
    if palavra[0] == palavra[-1]:
        palavras_selecionadas.append(palavra)

print("Palavras selecionadas:", palavras_selecionadas)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 25. Crie um programa em Python que leia um número do usuário e verifique se ele é um número perfeito. Um número perfeito é aquele que é igual à soma de seus divisores próprios (ou seja, a soma de seus fatores inteiros positivos, excluindo ele próprio).

# COMMAND ----------

numero = int(input("Digite um número: "))

divisores = []
for i in range(1, numero):
    if numero % i == 0:
        divisores.append(i)

if sum(divisores) == numero:
    print(numero, "é um número perfeito!")
else:
    print(numero, "não é um número perfeito.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 26. Crie um programa em Python que calcule a série de Fibonacci para um determinado número de termos fornecido pelo usuário. A série de Fibonacci é uma sequência em que cada número é a soma dos dois números anteriores: 0, 1, 1, 2, 3, 5, 8, 13, ...

# COMMAND ----------

termos = int(input("Digite o número de termos desejados: "))
fibonacci = [0, 1]
i = 2

while i < termos:
    fibonacci.append(fibonacci[i-1] + fibonacci[i-2])
    i += 1

print("A sequência de Fibonacci com", termos, "termos é:")
print(fibonacci)

# COMMAND ----------

