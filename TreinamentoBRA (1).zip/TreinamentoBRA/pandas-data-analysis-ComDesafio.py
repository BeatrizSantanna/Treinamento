# Databricks notebook source
# MAGIC %md
# MAGIC # Case de Análise de Dados no Pandas!
# MAGIC
# MAGIC Iremos usar o banco de dados [Online Retail.xlsx](https://archive.ics.uci.edu/ml/datasets/Online+Retail), disponível no [Repositório de Dados para Machine Learning da UCI](https://archive.ics.uci.edu/ml/index.php). Para efeitos didáticos, eu fiz uma transformação no banco de dados para incluir a coluna `region`, que contém o nome do país assim como do continente.
# MAGIC
# MAGIC ![title](https://raw.githubusercontent.com/amauri-ti/labdata/main/imgs/uci-logo.png)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Importando as bibliotecas necessárias e o banco de dados

# COMMAND ----------

import numpy as np
import pandas as pd

# COMMAND ----------

df = spark.read.csv("/FileStore/tables/retail__1_-1.CSV", header=True, sep=';')
df = df.toPandas()

# COMMAND ----------

df.head()

# COMMAND ----------

display(dbutils.fs.ls('/FileStore/tables/'))

# COMMAND ----------

# MAGIC %md
# MAGIC #### Significado das colunas:
# MAGIC
# MAGIC * `invoice_no`: número do pedido
# MAGIC * `stock_code`: número único que caracteriza o item/produto (SKU)
# MAGIC * `description`: descrição/nome do produto
# MAGIC * `quantity`: quantidade do produto vendida
# MAGIC * `invoice_date`: data em que o pedido foi realizado
# MAGIC * `unit_price`: preço unitário
# MAGIC * `customer_id`: identificador único do cliente
# MAGIC * `region`: região de onde o cliente realizou a compra

# COMMAND ----------

# MAGIC %md
# MAGIC # Operações básicas de dados no Pandas

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Selecionando colunas
# MAGIC
# MAGIC Existem 2 formas de selecionar colunas no Pandas: a primeira é usando o `parênteses` e a segunda usando o método `filter()`.

# COMMAND ----------

df[['stock_code', 'unit_price']]

# COMMAND ----------

df.filter(['stock_code', 'unit_price'])

# COMMAND ----------

df.filter(like='id')

# COMMAND ----------

toy_df = pd.DataFrame({'pedido_id': [1, 1, 2, 3, 3], 
                       'produto_id': [251, 985, 390, 204, 985], 
                       'descricao': ['carro', 'boneca', 'celular', 'caderno', 'boneca'], 
                       'data_compra': ['2020-03-01', '2020-03-01', '2020-03-02', '2020-03-03', '2020-03-03'], 
                       'data_entrega': ['2020-03-02', '2020-03-02', '2020-03-03', '2020-03-04', '2020-03-04'], 
                       'valor_item': [25000, 30, 2000, 15, 30], 
                       'quantidade': [1, 1, 1, 2, 3]})
toy_df

# COMMAND ----------

toy_df.shape

# COMMAND ----------

toy_df.filter(like='data')

# COMMAND ----------

toy_df.filter(like='id')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Filtros
# MAGIC
# MAGIC Também existem duas formas de realizar filtros no Pandas: uma com `parênteses` e outra com o método `query()`.

# COMMAND ----------

df[df['invoice_no'] == '536368']

# COMMAND ----------

df.query('invoice_no == "536368"')

# COMMAND ----------

# MAGIC %md
# MAGIC #### Filtrando com duas condições
# MAGIC
# MAGIC Condição `and`

# COMMAND ----------

df[(df['invoice_no'] == '536368') & (df['stock_code'] == '22960')]

# COMMAND ----------

df.query('invoice_no == "536368" and stock_code == "22960"')

# COMMAND ----------

# MAGIC %md
# MAGIC Condição `or`

# COMMAND ----------

df[(df['invoice_no'] == '536368') | (df['stock_code'] == '22960')]

# COMMAND ----------

df.query('invoice_no == "536368" or stock_code == "22960"')

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. Criando novas colunas
# MAGIC
# MAGIC Existem duas formas de criar colunas com o Pandas: uma com `parênteses` e outra usando o método `assign()`.

# COMMAND ----------

df['total_price'] = df['quantity'] + df['unit_price']

# COMMAND ----------

df.head()

# COMMAND ----------

df.drop('total_price', axis=1, inplace=True)

# COMMAND ----------

df.assign(total_price = df['quantity'] + df['unit_price']).head()

# COMMAND ----------

df.head()

# COMMAND ----------

# MAGIC %md
# MAGIC O método `assign()` não modifica a tabela inplace. O que o torna uma boa opção para validar a nova coluna criada antes de efetivamente adicioná-la na tabela.

# COMMAND ----------

df.head()

# COMMAND ----------

# MAGIC %md
# MAGIC Para salvar a coluna de fato, devemos atribuir a operação para uma tabela.

# COMMAND ----------

df = df.assign(total_price = df['quantity'] + df['unit_price'])

# COMMAND ----------

df.head()

# COMMAND ----------

df.drop('total_price', axis=1, inplace=True)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Ordenando colunas
# MAGIC
# MAGIC Aqui, existem apenas um método: `sort_values()`.

# COMMAND ----------

df.sort_values('invoice_date').head()

# COMMAND ----------

df.sort_values('invoice_date', ascending=False).head()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. Aggregações
# MAGIC
# MAGIC No Pandas podemos criar agregações de duas formas: em uma coluna ou em grupos.
# MAGIC
# MAGIC ### Agregações em uma coluna

# COMMAND ----------

df['invoice_date'].min()

# COMMAND ----------

df['invoice_date'].max()

# COMMAND ----------

df.agg({'invoice_date': ['min', 'max']})

# COMMAND ----------

# MAGIC %md
# MAGIC ### Agregações no método `groupby()`

# COMMAND ----------

df.groupby('invoice_no').agg(n=('stock_code', 'count')).reset_index()

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. Combinando as operações

# COMMAND ----------

# MAGIC %md
# MAGIC Limpando os nossos dados. Pedidos com começam com a letra `C` foram cancelados, logo devem ser retirados da base de dados.
# MAGIC Também temos pedidos com quantidades negativas, que significa que ou foram cancelados ou estornados.

# COMMAND ----------


df = (
   df
   .assign(start_with_c = lambda x: x['invoice_no'].str.startswith('C'))
   .assign(quantity = lambda x: df['quantity'].astype(int))
   .query('start_with_c == False')
   .query('quantity >= 0')
)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Realize uma 'query' que retorne os top 10 pedidos com mais itens.

# COMMAND ----------

df.groupby('invoice_no').agg(n=('stock_code', 'count')).reset_index().sort_values('n', ascending=False).head(10)

# COMMAND ----------

# MAGIC %md
# MAGIC Traga a data em que o pedido foi realizado

# COMMAND ----------

(
    df
    .groupby('invoice_no')
    .agg(n        = ('stock_code', 'count'), 
         datetime = ('invoice_date', 'first'))
    .reset_index()
    .sort_values('n', ascending=False)
    .head(10)
)

# COMMAND ----------

# MAGIC %md
# MAGIC Crie uma coluna apenas com a data --> valendo 1 ponto
# MAGIC ### -> retornamos segunda

# COMMAND ----------

import datetime as dt
from datetime import date

# COMMAND ----------

df_copy = df.copy()

df_copy['invoice_date'] = pd.to_datetime(df_copy['invoice_date']).dt.date

grouped = df_copy.groupby('invoice_no').agg(
    n=('stock_code', 'count'), 
    datetime=('invoice_date', 'first')
)

result = grouped.reset_index()
top_10 = result.sort_values('n', ascending=False).head(10)
top_10

# COMMAND ----------

# MAGIC %md
# MAGIC No pandas, assim como no SQL, não conseguimos referenciar uma coluna que acabou de ser criada. Para conseguirmos fazer isso, podemos usar funções lambda!
# MAGIC
# MAGIC DESAFIO VALENDO 1 PONTO! CASA!

# COMMAND ----------

grouped = df.groupby('invoice_no').agg(
    n=('stock_code', 'count'), 
    datetime=('invoice_date', 'first')
)

result = grouped.reset_index()

top_10 = result.sort_values('n', ascending=False).head(10)
top_10 = top_10.assign(date=pd.to_datetime(top_10['datetime']).dt.date)
top_10

# COMMAND ----------

# MAGIC %md
# MAGIC A coluna `datetime` não é do time datetime. Ela é do tipo `object`.

# COMMAND ----------

grouped = df.groupby('invoice_no').agg(
    n=('stock_code', 'count'), 
    datetime=('invoice_date', 'first')
)

result = grouped.reset_index()
top_10 = result.sort_values('n', ascending=False).head(10)
print(top_10.dtypes)

# COMMAND ----------

# MAGIC %md
# MAGIC Então, para resolvermos o problema temos que transformar o tipo da coluna para datetime e só depois conseguiremos performar a operação desejada.

# COMMAND ----------

grouped = df.groupby('invoice_no').agg(
    n=('stock_code', 'count'), 
    datetime=('invoice_date', 'first')
)

result = grouped.reset_index()

top_10 = result.sort_values('n', ascending=False).head(10)
top_10['datetime'] = pd.to_datetime(top_10['datetime'])
print(top_10.dtypes)

# COMMAND ----------

grouped = df.groupby('invoice_no').agg(
    n=('stock_code', 'count'), 
    datetime=('invoice_date', 'first')
)

result = grouped.reset_index()

top_10 = result.sort_values('n', ascending=False).head(10)
top_10['datetime'] = pd.to_datetime(top_10['datetime'])
top_10['date'] = top_10['datetime'].dt.date
print(top_10)

# COMMAND ----------

(
    df
    .groupby('invoice_no')
    .agg(n        = ('stock_code', 'count'), 
         datetime = ('invoice_date', 'first'))
    .reset_index()
    .sort_values('n', ascending=False)
    .head(10)
    .assign(datetime = lambda x: pd.to_datetime(x['datetime']))
    .assign(date = lambda x: x['datetime'].dt.date)
)

# COMMAND ----------

# MAGIC %md
# MAGIC Agora, vamos dropar a coluna `datetime`. 
# MAGIC
# MAGIC Jeito 1:

# COMMAND ----------

(
    df
    .groupby('invoice_no')
    .agg(n        = ('stock_code', 'count'), 
         datetime = ('invoice_date', 'first'))
    .reset_index()
    .sort_values('n', ascending=False)
    .head(10)
    .assign(datetime = lambda x: pd.to_datetime(x['datetime']))
    .assign(date = lambda x: x['datetime'].dt.date)
    .drop('datetime', axis=1)
)

# COMMAND ----------

# MAGIC %md
# MAGIC Jeito 2:

# COMMAND ----------

(
    df
    .groupby('invoice_no')
    .agg(n        = ('stock_code', 'count'), 
         datetime = ('invoice_date', 'first'))
    .reset_index()
    .sort_values('n', ascending=False)
    .head(10)
    .assign(datetime = lambda x: pd.to_datetime(x['datetime']))
    .assign(date = lambda x: x['datetime'].dt.date)
    .filter(['invoice_no', 'n', 'date'])
)

# COMMAND ----------

top_10_invoice_df = (
    df
    .groupby('invoice_no')
    .agg(n        = ('stock_code', 'count'), 
         datetime = ('invoice_date', 'first'))
    .reset_index()
    .sort_values('n', ascending=False)
    .head(10)
    .assign(datetime = lambda x: pd.to_datetime(x['datetime']))
    .assign(date = lambda x: x['datetime'].dt.date)
    .filter(['invoice_no', 'n', 'date'])
)

# COMMAND ----------

top_10_invoice_df

# COMMAND ----------

# MAGIC %md
# MAGIC ### Vamos fazer um gráfico de barras

# COMMAND ----------

top_10_invoice_df.plot(kind='bar', x='invoice_no', y='n', rot=45);

# COMMAND ----------

import seaborn as sns
import matplotlib.pyplot as plt


sns.barplot(data=top_10_invoice_df, x='invoice_no', y='n');

# COMMAND ----------

fig, ax = plt.subplots(figsize=(10, 5))

sns.barplot(data=top_10_invoice_df, x='invoice_no', y='n', ax=ax, color='green');
ax.set_ylabel('Qtde de items no pedido', fontsize=13);
ax.set_xlabel('Pedido', fontsize=13);
ax.set_title('Top 10 Pedidos com mais Items', fontsize=15);

# COMMAND ----------

import matplotlib.pyplot as plt

# COMMAND ----------

sns.set_style('darkgrid')

fig, ax = plt.subplots(figsize=(10, 5))

sns.barplot(data=top_10_invoice_df, x='invoice_no', y='n', ax=ax, color='green');
ax.set_ylabel('Qtde de items no pedido', fontsize=13);
ax.set_xlabel('Pedido', fontsize=13);
ax.set_title('Top 10 Pedidos com mais Items', fontsize=15);

# COMMAND ----------

# MAGIC %md
# MAGIC ### Vamos fazer um boxplot do preço total do pedido
# MAGIC
# MAGIC valendo 0,5!

# COMMAND ----------

# Necessárioi tratar os valores presentes em unit_price. Substituir a virgula por um ponto e transformar em float

df['unit_price'] = df['unit_price'].astype(object)

revenue_by_invoice_df = (
   df
   .assign(b = lambda x: x['unit_price'].replace(',','.',regex=True).astype(float))
   .assign(total_price = lambda x: x['quantity'] * x['b'])
   .groupby('invoice_no')
   .agg(revenue = ('total_price', 'sum'))
   .reset_index()
)

# COMMAND ----------

fig, ax = plt.subplots(figsize=(10, 4))

sns.boxplot(data=revenue_by_invoice_df, x='revenue', ax=ax);

# COMMAND ----------

# MAGIC %md
# MAGIC Vamos fazer o mesmo boxplot, mas para cada mês
# MAGIC
# MAGIC valendo 0,5!

# COMMAND ----------

# Necessárioi tratar os valores presentes em unit_price. Substituir a virgula por um ponto e transformar em float
df['unit_price'] = df['unit_price'].astype(object)

revenue_invoice_month_df = (
    df
    .assign(b = lambda x: x['unit_price'].replace(',','.',regex=True).astype(float))
    .assign(invoice_date = lambda x: pd.to_datetime(x['invoice_date']))
    .assign(month = lambda x: x['invoice_date'].dt.month)
    .assign(total_price = lambda x: x['b'] * x['quantity'])
    .filter(['invoice_no','month','total_price'])
    .groupby('invoice_no')
    .agg(month = ('month', 'first'),
         revenue = ('total_price', 'sum'))
    .reset_index()
)
revenue_invoice_month_df

# COMMAND ----------

fig, ax = plt.subplots(figsize=(14, 6))


sns.boxplot(data=revenue_invoice_month_df, y='revenue', x='month', ax=ax);
ax.set_xlabel('month', fontsize=15);
ax.set_ylabel('revenue', fontsize=15);

# COMMAND ----------

# MAGIC %md
# MAGIC # Vamos calcular a receita por país

# COMMAND ----------

df.head()

# COMMAND ----------

df[['country', 'continent']] = df['region'].str.split(n=1, expand=True)

# COMMAND ----------

df.head()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Podemos criar uma função

# COMMAND ----------

# o separador do campo Region deve ser o espaço. o comando "n=1" limita o número de splits para apenas uma vez
def separate_col(data, col, into):
    df = data.copy()
    df[into] = df[col].astype("string").str.split(n=1, expand=True)
    return df

# COMMAND ----------

df.head()

# COMMAND ----------

df = df.drop(['country', 'continent'], axis=1)

# COMMAND ----------

df.head()

# COMMAND ----------

separate_col(df, col='region', into=['country', 'continent'])

# COMMAND ----------

df.pipe(separate_col, col='region', into=['country', 'continent'])

# COMMAND ----------

# MAGIC %md
# MAGIC Vamos generalizar a nossa função! Vamos incluir o argumento `sep` e `keep`.

# COMMAND ----------

# o separador do campo Region deve ser o espaço e o comando "n=1" limita o número de splits para apenas uma vez

def separate_col(data, col, into, sep=' ', keep=True):
    df = data.copy()
    df[into] = df[col].str.split(sep, n=1, expand=True)
    
    if keep:
        return df
    else:
        df = df.drop(col, axis=1)
        return df

# COMMAND ----------

df.pipe(separate_col, col='region', into=['country', 'continent'])

# COMMAND ----------

# False deleta a coluna Region
df.pipe(separate_col, col='region', into=['country', 'continent'], keep=False)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Retorne os 10 países com as maiores receitas.

# COMMAND ----------

# Necessárioi tratar os valores presentes em unit_price. Substituir a virgula por um ponto e transformar em float

top10_revenue_by_country_df = (
    df
    .pipe(separate_col, col='region', into=['country', 'continent'], keep=False)
    .assign(b = lambda x: x['unit_price'].replace(',','.',regex=True).astype(float))
    .assign(total_price = lambda x: round(x['quantity'] * x['b'], 2))
    .groupby('country')
    .agg(revenue = ('total_price', 'sum'))
    .sort_values('revenue', ascending=False)
    .reset_index()
    .head(10)
)

# COMMAND ----------

top10_revenue_by_country_df.filter(['revenue'])

# COMMAND ----------

fig, ax = plt.subplots(figsize=(8, 6))

sns.barplot(data=top10_revenue_by_country_df, y='country', x='revenue', ax=ax, color='green');
ax.set_ylabel('Country', fontsize=13);
ax.set_xlabel('Revenu', fontsize=13);
ax.set_title('Revenue by Country', fontsize=15);

# COMMAND ----------

# MAGIC %md
# MAGIC ### Vez de vocês! Façam o mesmo, mas para os continentes!

# COMMAND ----------

# Necessárioi tratar os valores presentes em unit_price. Substituir a virgula por um ponto e transformar em float
# Agrupar por continente ao invés de país
top10_revenue_by_continent_df = (
    df
    .pipe(separate_col, col='region', into=['country', 'continent'], keep=False)
    .assign(b = lambda x: x['unit_price'].replace(',','.',regex=True).astype(float))
    .assign(total_price = lambda x: round(x['quantity'] * x['b'], 2))
    .groupby('continent')
    .agg(revenue = ('total_price', 'sum'))
    .sort_values('revenue', ascending=False)
    .reset_index()
    .head(10)
)

top10_revenue_by_continent_df

# COMMAND ----------

fig, ax = plt.subplots(figsize=(20, 6))

sns.barplot(data=top10_revenue_by_continent_df, y='continent', x='revenue', ax=ax, color='green');
ax.set_ylabel('continent', fontsize=13);
ax.set_xlabel('Revenu', fontsize=13);
ax.set_title('Revenue by continent', fontsize=15);

#O Revenu de Kingdom é significativamente maior do que os outros

# COMMAND ----------

# MAGIC %md
# MAGIC ### Vamos calcular, para cada cliente, o seu RFV

# COMMAND ----------

df.head()

# COMMAND ----------

from datetime import datetime, date

rfv_df = (
    df
    .assign(b = lambda x: x['unit_price'].replace(',','.',regex=True).astype(float))
    .assign(total_price = lambda x: round(x['quantity'] + x['b'], 2))
    .groupby(['customer_id'])
    .agg(revenue   = ('total_price', 'sum'), 
         frequency = ('invoice_no', 'count'), 
         last_shop = ('invoice_date', 'max'))
    .reset_index()
    .assign(last_shop = lambda x: pd.to_datetime(x['last_shop'], infer_datetime_format=True))
    .assign(ref_date = datetime.strptime('2012-01-01', '%Y-%m-%d'))
    .assign(recency = lambda x: (x['ref_date'] - x['last_shop']).dt.days)
    .filter(['ref_date', 'customer_id', 'revenue', 'frequency', 'recency'])
    .reset_index()
)

# COMMAND ----------

rfv_df

# COMMAND ----------

