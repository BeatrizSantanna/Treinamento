# Databricks notebook source
# MAGIC %md
# MAGIC ### 16. Crie um programa em Python que receba uma lista de dicionários como entrada, onde cada dicionário representa um aluno com nome e notas em diferentes disciplinas, e retorne o nome do aluno com a maior média ponderada, sendo que a média ponderada deve ser calculada utilizando as notas como pesos.

# COMMAND ----------

alunos = [{"nome": "João", "notas": {"Matemática": 8.5, "Português": 9.0, "História": 7.0}},
          {"nome": "Maria", "notas": {"Matemática": 9.5, "Português": 8.5, "História": 6.0}},
          {"nome": "Pedro", "notas": {"Matemática": 7.0, "Português": 6.5, "História": 9.0}},
          {"nome": "Ana", "notas": {"Matemática": 8.0, "Português": 7.5, "História": 8.0}}]

aluno_com_maior_media_ponderada = max(alunos, key=lambda aluno: (aluno["notas"]["Matemática"] * 2 + aluno["notas"]["Português"] * 3 + aluno["notas"]["História"] * 2) / 7)
nome_do_aluno_com_maior_media_ponderada = aluno_com_maior_media_ponderada["nome"]

print(nome_do_aluno_com_maior_media_ponderada)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 17. Crie um programa em Python que receba três números como entrada e imprima "Maior" se o primeiro número for maior do que a soma dos outros dois, "Menor" se o primeiro número for menor do que a soma dos outros dois, ou "Igual" caso contrário.

# COMMAND ----------

num1 = float(input("Digite o primeiro número: "))
num2 = float(input("Digite o segundo número: "))
num3 = float(input("Digite o terceiro número: "))

if num1 > num2 + num3:
    print("Maior")
elif num1 < num2 + num3:
    print("Menor")
else:
    print("Igual")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 18. Crie um programa em Python que receba a idade e a altura de uma pessoa como entrada e classifique-a de acordo com as seguintes regras: se a idade for menor do que 18 anos e a altura for menor do que 1,60 m, imprimir "Adolescente Baixo"; se a idade for menor do que 18 anos e a altura for maior do que 1,60 m, imprimir "Adolescente Alto"; se a idade for maior ou igual a 18 anos e a altura for menor do que 1,60 m, imprimir "Adulto Baixo"; se a idade for maior ou igual a 18 anos e a altura for maior do que 1,60 m, imprimir "Adulto Alto".

# COMMAND ----------

idade = int(input("Digite a idade: "))
altura = float(input("Digite a altura: "))

if idade < 18 and altura < 1.60:
    print("Adolescente Baixo")
elif idade < 18 and altura >= 1.60:
    print("Adolescente Alto")
elif idade >= 18 and altura < 1.60:
    print("Adulto Baixo")
else:
    print("Adulto Alto")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 19. Crie um programa em Python que receba uma string como entrada e imprima "Palíndromo" se a string for um palíndromo (ou seja, se a string lida de trás para frente for igual à string original), ou "Não Palíndromo" caso contrário.

# COMMAND ----------

texto = input("Digite um texto: ")

if texto == texto[::-1]:
    print("Palíndromo")
else:
    print("Não Palíndromo")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 20. Crie um programa em Python que receba uma lista de números inteiros como entrada e calcule a soma dos quadrados dos números ímpares da lista.

# COMMAND ----------

numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9]

soma_quadrados_impares = 0
for num in numeros:
    if num % 2 != 0:
        soma_quadrados_impares += num ** 2

print("A soma dos quadrados dos números ímpares da lista é:", soma_quadrados_impares)