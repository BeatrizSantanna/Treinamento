# Databricks notebook source
# MAGIC %md
# MAGIC ### 1. Ler e exibir um arquivo CSV usando pandas

# COMMAND ----------

import pandas as pd

df = spark.read.csv("dbfs:/FileStore/tables/retail.csv", header=True, sep=',')
df = df.toPandas()

df

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. Selecionar colunas específicas de um DataFrame usando pandas

# COMMAND ----------

df.filter(['stock_code', 'description', 'quantity', 'region'])

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3. Filtrar linhas com base em uma condição usando pandas

# COMMAND ----------

df[(df['region'] == 'United Kingdom') & (df['quantity'] == '10')]

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4. Agrupar dados com base em uma coluna usando pandas

# COMMAND ----------

df.agg({'invoice_date': ['min', 'max']})

# COMMAND ----------

top_10_invoice = (
    df
    .groupby('invoice_no')
    .agg(n        = ('stock_code', 'count'),
         datatime = ('invoice_date', 'first'))
    .reset_index()
    .sort_values('n', ascending=False)
    .head(10)
    .assign(date = date(2020, 3, 10))
)

top_10_invoice

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5. Usar a função max em alguma coluna do DataFrame

# COMMAND ----------

df['quantity'].max()