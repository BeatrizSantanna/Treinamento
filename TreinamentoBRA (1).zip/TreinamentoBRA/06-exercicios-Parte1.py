# Databricks notebook source
# MAGIC %md
# MAGIC ### 1. Crie um programa em Python que receba uma string como entrada e imprima uma nova string com os caracteres na ordem inversa.

# COMMAND ----------

string = input("Digite uma string: ")
string_invertida = string[::-1]
print(string_invertida)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 2. Crie um programa em Python que receba uma string como entrada e imprima outra string com todas as palavras em ordem inversa.

# COMMAND ----------

string = input("Digite uma string: ")
palavras = string.split()
palavras_invertidas = list(reversed(palavras))
string_invertida = " ".join(palavras_invertidas)
print(string_invertida)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 3. Crie um programa em Python que receba uma string como entrada e imprima outra string com todas as vogais substituídas por asteriscos (*)

# COMMAND ----------

string = input("Digite uma string: ")
string_sem_vogal = ""

for caractere in string:
    if caractere in "aeiouAEIOU":
        string_sem_vogal += "*"
    else:
        string_sem_vogal += caractere

print(string_sem_vogal)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 4. Crie um programa em Python que receba uma string como entrada e imprima outra string com todas as palavras que começam com letra maiúscula.

# COMMAND ----------

string = input("Digite uma string: ")
palavras = string.split()
palavras_maiusculas = []

for palavra in palavras:
    if palavra[0].isupper():
        palavras_maiusculas.append(palavra)

if len(palavras_maiusculas) == 0:
    print("Não foram encontradas palavras maiúsculas na frase.")
else:
    print("Palavras maiúsculas encontradas: ", " ".join(palavras_maiusculas))

# COMMAND ----------

# MAGIC %md
# MAGIC ### 5. Crie um programa em Python que receba uma string como entrada e verifique se ela é um palíndromo (ou seja, se pode ser lida da mesma forma da esquerda para a direita e da direita para a esquerda).

# COMMAND ----------

texto = input("Digite uma string: ")

if texto == texto[::-1]:
    print("A string é um palíndromo.")
else:
    print("A string não é um palíndromo.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 6. Crie um programa em Python que receba uma string como entrada e verifique se ela é um anagrama de outra string. (ou seja, se elas possuem as mesmas letras em quantidades diferentes)

# COMMAND ----------

texto1 = input("Digite a primeira string: ")
texto2 = input("Digite a segunda string: ")

texto1 = texto1.replace(" ", "").lower()
texto2 = texto2.replace(" ", "").lower()

freq1 = {}
freq2 = {}

for letra in texto1:
    if letra in freq1:
        freq1[letra] += 1
    else:
        freq1[letra] = 1

for letra in texto2:
    if letra in freq2:
        freq2[letra] += 1
    else:
        freq2[letra] = 1

if freq1 == freq2:
    print("As strings são anagramas uma da outra.")
else:
    print("As strings não são anagramas uma da outra.")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 7. Crie um programa em Python que receba uma string como entrada e imprima outra string que é formada pela primeira letra de cada palavra da string original.

# COMMAND ----------

texto = input("Digite uma string: ")
palavras = texto.split()

nova_string = ""

for palavra in palavras:
    primeira_letra = palavra[0]
    nova_string += primeira_letra

print(nova_string)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 8. Crie um programa em Python que receba uma tupla de números inteiros como entrada e retorne uma nova tupla contendo apenas os números primos.

# COMMAND ----------

numeros = (2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20)
numeros_primos = []

for num in numeros:
    if num > 1:
        for i in range(2, num):
            if (num % i) == 0:
                break
        else:
            numeros_primos.append(num)

tupla_primos = tuple(numeros_primos)

print(tupla_primos)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 9. Crie um programa em Python que receba duas tuplas de números inteiros como entrada e retorne uma nova tupla contendo apenas os elementos que aparecem em ambas as tuplas.

# COMMAND ----------

tupla1 = (1, 2, 3, 4, 5)
tupla2 = (3, 4, 5, 6, 7)
tupla_intersecao = tuple(set(tupla1).intersection(set(tupla2)))
print(tupla_intersecao)

# COMMAND ----------

# MAGIC %md
# MAGIC ### 10. Crie um programa em Python que receba uma tupla de strings como entrada e retorne uma nova tupla contendo apenas as strings que começam e terminam com a mesma letra.

# COMMAND ----------

tupla = ("arara", "casa", "mala", "ovo", "paralelepípedo", "pato")
nova_tupla = tuple(s for s in tupla if s[0] == s[-1])
print(nova_tupla)